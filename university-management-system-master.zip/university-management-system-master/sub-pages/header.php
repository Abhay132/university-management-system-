<body>
	<!--[if lt IE 8]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->

	<!--my coding start from here -->
	
	<div class="wrapper clear">

		<header class="header clear">
			<div class="header-left clear">
				<h2>University Management System</h2>
			</div>
			<div class="header-right clear">
				
			</div>
		</header>