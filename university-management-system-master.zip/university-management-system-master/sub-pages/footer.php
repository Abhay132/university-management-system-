
			<footer class="main-footer clear">
				<div class="footer-left clear">
					<p>2016 &copy; University Management</p>
				</div>
				<div class="footer-right clear">
					<p>Developed by Abdullah</p>
				</div>
			</footer>
		</div>
		
		<script type="text/javascript">
			$(document).ready(function(e){
				$('.sub-menu').click(function(){
					$(this).toggleClass('tap');
				});
			});
		
		</script>

	</body>
</html>
