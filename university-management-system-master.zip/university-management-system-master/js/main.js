$(document).ready(function(){
	$('#nav').slicknav();
	 $("#responsive-videos").fitVids();
});