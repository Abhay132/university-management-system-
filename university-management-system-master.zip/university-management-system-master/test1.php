<html>
	<head>
		<title>Constants</title>
	</head>
	<body>
		<?php
			define("MAX_WIDTH", 980);
			echo MAX_WIDTH."<br>";
			runkit_constant_redefine("MAX_WIDTH",1);
			echo MAX_WIDTH;
		?>
</html>